﻿using OnlineRecruitmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace OnlineRecruitmentSystem.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Signup()
        {
            ViewBag.Message = "Sign up page.";

            return View();
        }
        [HttpPost]
        public ActionResult Signup(JobSeekerPersInfo seeker)
        {
            HttpResponseMessage response = GlobalVariables.WebApiClient.PostAsJsonAsync("JobSeekerPersInfoes", seeker).Result;
            return RedirectToAction("Index");
        }
        
        public ActionResult Login()
        {
            ViewBag.Message = "Login page.";

            return View();
        }
        public ActionResult Admin()
        {
            ViewBag.Message = "Admin Login page.";

            return View();
        }
        public ActionResult Employer()
        {
            ViewBag.Message = "Employer signup page.";

            return View();
        }
        public ActionResult EmployerLogin()
        {
            ViewBag.Message = "Employer Login page.";

            return View();
        }
        public ActionResult EducationalInfo()
        {
            ViewBag.Message = "Employer Login page.";

            return View();
        }

    }
}