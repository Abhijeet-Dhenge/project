﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CIMS_MVC.Models;

namespace CIMS_MVC.Controllers
{
    public class CarsController : Controller
    {
        private CMSEntities db = new CMSEntities();

        // GET: Cars

        public ActionResult Menu()
        {
            return View();
        }

        public ActionResult Index()
        {
            var cars = db.Cars.Include(c => c.Manufacturer_4315).Include(c => c.CarTransmissionType_4315).Include(c => c.CarType_4315);
            return View(cars.ToList());
        }

        // GET: Cars/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.Cars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // GET: Cars/Create
        public ActionResult Create()
        {
            ViewBag.ManufacturerId = new SelectList(db.Manufacturer_4315, "Id", "ManufacturerName");
            ViewBag.TransmissionId = new SelectList(db.CarTransmissionType_4315, "Id", "TransmissionName");
            ViewBag.TypeId = new SelectList(db.CarType_4315, "Id", "CarType");
            return View();
        }

        // POST: Cars/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Model,ManufacturerId,TypeId,Engine,BHP,TransmissionId,Mileage,Seat,AirBagDetails,BootSpace,Price")] Car car)
        {
            if (ModelState.IsValid)
            {
                db.Cars.Add(car);
                db.SaveChanges();
                return RedirectToAction("Menu");
            }

            ViewBag.ManufacturerId = new SelectList(db.Manufacturer_4315, "Id", "ManufacturerName", car.ManufacturerId);
            ViewBag.TransmissionId = new SelectList(db.CarTransmissionType_4315, "Id", "TransmissionName", car.TransmissionId);
            ViewBag.TypeId = new SelectList(db.CarType_4315, "Id", "CarType", car.TypeId);
            return View(car);
        }

        // GET: Cars/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.Cars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            ViewBag.ManufacturerId = new SelectList(db.Manufacturer_4315, "Id", "ManufacturerName", car.ManufacturerId);
            ViewBag.TransmissionId = new SelectList(db.CarTransmissionType_4315, "Id", "TransmissionName", car.TransmissionId);
            ViewBag.TypeId = new SelectList(db.CarType_4315, "Id", "CarType", car.TypeId);
            return View(car);
        }

        // POST: Cars/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Model,ManufacturerId,TypeId,Engine,BHP,TransmissionId,Mileage,Seat,AirBagDetails,BootSpace,Price")] Car car)
        {
            if (ModelState.IsValid)
            {
                db.Entry(car).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Menu");
            }
            ViewBag.ManufacturerId = new SelectList(db.Manufacturer_4315, "Id", "ManufacturerName", car.ManufacturerId);
            ViewBag.TransmissionId = new SelectList(db.CarTransmissionType_4315, "Id", "TransmissionName", car.TransmissionId);
            ViewBag.TypeId = new SelectList(db.CarType_4315, "Id", "CarType", car.TypeId);
            return View(car);
        }

        // GET: Cars/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.Cars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // POST: Cars/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Car car = db.Cars.Find(id);
            db.Cars.Remove(car);
            db.SaveChanges();
            return RedirectToAction("Menu");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult ModifyByModel(string model)
        {
            List<Car> cars = db.Cars.Where(x => x.Model == model).ToList();
            if (cars.Count > 0)
            {
                return RedirectToAction("Edit", new { id= cars[0].Id});
            }
            return View();
        }

        public ActionResult RemoveByModel(string model)
        {
            List<Car> cars = db.Cars.Where(x => x.Model == model).ToList();
            if (cars.Count > 0)
            {
                return RedirectToAction("Delete", new { id = cars[0].Id });
            }
            return View();
        }

        public ActionResult SearchByManufacturer(string manufacturer)
        {
            if (manufacturer != null)
            {
                    List<Car> cars = db.Cars.Where(x => x.Manufacturer_4315.ManufacturerName == manufacturer).ToList();
                    if (cars.Count > 0)
                    {
                        return View(cars);
                    }
            }
            
            
            return View();
        }

        public ActionResult SearchByModel(string model)
        {
            List<Car> cars = db.Cars.Where(x => x.Model == model).ToList();
            if (cars.Count>0)
            {
                return View(cars[0]);
            }
            return View();
        }


    }
}
