﻿using OnlineRecruitmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace OnlineRecruitmentSystem.Controllers
{
    
    public class HomeController : Controller
    {
        private Training_13Aug19_PuneEntities2 db = new Training_13Aug19_PuneEntities2();
        static JobSeekerLogin eduinfo = new JobSeekerLogin();
        public ActionResult Index()
        {
            return View();
        } 

        [HttpGet]
        public ActionResult Menu()
        {
            return View();
        }
        public ActionResult AddedJobIndex()
        {
            var jobOpeningInfoes = db.JobOpeningInfoes.Include(j => j.EmployerInfo).Include(j => j.JobsAppliedInfo);
            return View(jobOpeningInfoes.ToList());
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Signup()
        {
            ViewBag.Message = "Sign up page.";

            return View();
        }
        [HttpPost]
        public ActionResult Signup(JobSeekerPersInfo seeker)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/RegisterJobSeeker");
            var regseeker = hc.PostAsJsonAsync<JobSeekerPersInfo>("", seeker);
            regseeker.Wait();
            TempData["SuccessMessage"] = "Saved Successfully";
            return RedirectToAction("EducationalInfo");
        }
        [HttpGet]
        public ActionResult Login()
        {
            //ViewBag.Message = "Login page.";

            return View();
        }
        
        public ActionResult Login(string username, string password)
        {
            //JobSeekerLogin eduinfo = null;
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/LoginJobSeeker");
            var responseTask = hc.GetAsync($"?username={username}&password={password}");
            responseTask.Wait();

            var result = responseTask.Result;
            if(result.IsSuccessStatusCode)
            {
                var readTask = result.Content.ReadAsAsync<JobSeekerLogin>();
                readTask.Wait();
                eduinfo = readTask.Result;
                //Session["loggedInAs"] = eduinfo;
                return RedirectToAction("LoggedIn", new RouteValueDictionary(new { controller = "Home", action = "LoggedIn" }));
            }
            //else
            //{
            //    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
            //}

            return View();
        }
        [HttpGet]
        public ActionResult LoggedIn()
        {
           
                return View(eduinfo);
            
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobSeekerEducInfo jobSeekerEducInfo = db.JobSeekerEducInfoes.Find(id);
            if (jobSeekerEducInfo == null)
            {
                return HttpNotFound();
            }
            ViewBag.JobSeekerId = new SelectList(db.JobSeekerPersInfoes, "JobSeekerId", "FirstName", jobSeekerEducInfo.JobSeekerId);
            return View(jobSeekerEducInfo);
        }

        // POST: JobSeekerEducInfoes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "JobSeekerId,InstituteName,MaxQualification,PassingYear,SSCPercent,HSCPercent,GraduationPercent,Skills,ProjectTitle,WorkExperience")] JobSeekerEducInfo jobSeekerEducInfo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(jobSeekerEducInfo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.JobSeekerId = new SelectList(db.JobSeekerPersInfoes, "JobSeekerId", "FirstName", jobSeekerEducInfo.JobSeekerId);
            return View(jobSeekerEducInfo);
        }



        public ActionResult Admin()
        {
            ViewBag.Message = "Admin Login page.";

            return View();
        }
        public ActionResult Employer()
        {
            ViewBag.Message = "Employer signup page.";

            return View();
        }
        [HttpPost]
        public ActionResult Employer(EmployerInfo employer)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/RegisterEmployer");
            var regemployer = hc.PostAsJsonAsync<EmployerInfo>("",employer);
            regemployer.Wait();
            TempData["SuccessMessage"] = "Registered Successfully";
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult EmployerLogin()
        {
            return View();
        }
        
        public ActionResult EmployerLogin(string username,string password)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/LoginEmployer");
            var responseTask = hc.GetAsync($"?username={username}&password={password}");
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {

                var readTask = result.Content.ReadAsAsync<EmployerInfo>();
                readTask.Wait();
                var res = readTask.Result;
                Session["EmpID"] = res.EmployerId;
                if (res != null)
                {
                    return RedirectToAction("Menu", new RouteValueDictionary(new { controller = "Home", action = "Menu" }));
                }
                else
                {
                    return RedirectToAction("EmployerLogin");
                }
            }
            
            
        
            return View();

        }

        [HttpGet]
        public ActionResult CreateJob()
        {
            //ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName");
            //ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateJob([Bind(Include = "EmployerId,JobCategory,JobLocation,RequiredSkills,Role1,MinQualification,MaxAge,Salary,JobDescription")] JobOpeningInfo jobOpeningInfo)
        {
            if (ModelState.IsValid)
            {
                jobOpeningInfo.EmployerId = (int)Session["EmpID"];
                db.JobOpeningInfoes.Add(jobOpeningInfo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            //ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName", jobOpeningInfo.EmployerId);
            //ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status", jobOpeningInfo.JobId);
            return View(jobOpeningInfo);
        }

        public ActionResult EducationalInfo()
        {
            ViewBag.Message = "Employer Login page.";

            return View();
        }

        [HttpPost]
        public ActionResult EducationalInfo(JobSeekerEducInfo eduinfo)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/EducationalDetails");
            var regemployer = hc.PostAsJsonAsync<JobSeekerEducInfo>("", eduinfo);
            
            regemployer.Wait();

            TempData["SuccessMessage"] = "Educational Detail Saved Successfully";
            return RedirectToAction("Index");
        }

        // GET: JobOpeningInfoes/Edit/5
        public ActionResult JobOpeningEdit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            if (jobOpeningInfo == null)
            {
                return HttpNotFound();
            }
            //ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName", jobOpeningInfo.EmployerId);
            //ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status", jobOpeningInfo.JobId);
            return View(jobOpeningInfo);
        }

        // POST: JobOpeningInfoes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult JobOpeningEdit([Bind(Include = "JobId,EmployerId,JobCategory,JobLocation,RequiredSkills,Role1,MinQualification,MaxAge,Salary,JobDescription")] JobOpeningInfo jobOpeningInfo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(jobOpeningInfo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("AddedJobIndex");
            }
            // ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName", jobOpeningInfo.EmployerId);
            //ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status", jobOpeningInfo.JobId);
            return View(jobOpeningInfo);
        }

        public ActionResult JobOpeningDelete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            if (jobOpeningInfo == null)
            {
                return HttpNotFound();
            }
            return View(jobOpeningInfo);
        }

        // POST: JobOpeningInfoes/Delete/5
        [HttpPost, ActionName("JobOpeningDelete")]
        [ValidateAntiForgeryToken]
        public ActionResult JobOpeningDelete(int id)
        {
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            db.JobOpeningInfoes.Remove(jobOpeningInfo);
            db.SaveChanges();
            return RedirectToAction("Menu");
        }

    }
}