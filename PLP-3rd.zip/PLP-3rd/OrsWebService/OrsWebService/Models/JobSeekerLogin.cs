﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrsWebService.Models
{
    public class JobSeekerLogin
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int JobSeekerId { get; set; }
        public string InstituteName { get; set; }
        public string MaxQualification { get; set; }
        public Nullable<System.DateTime> PassingYear { get; set; }
        public Nullable<double> SSCPercent { get; set; }
        public Nullable<double> HSCPercent { get; set; }
        public Nullable<double> GraduationPercent { get; set; }
        public string Skills { get; set; }
        public string ProjectTitle { get; set; }
        public Nullable<int> WorkExperience { get; set; }
    }
}