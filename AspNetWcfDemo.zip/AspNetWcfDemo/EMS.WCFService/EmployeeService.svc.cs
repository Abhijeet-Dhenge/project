﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace EMS.WCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class EmployeeService : IEmployeeService
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["bookconn"].ConnectionString);
        SqlCommand cmd;
        SqlDataReader dr;

        public bool AddEmployee(Employee employee)
        {
            bool employeeAdded = false;

            try
            {
                cmd = new SqlCommand("SelectEmployee_4315", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID",employee.Id);
                cmd.Parameters.AddWithValue("@Name", employee.Name);
                cmd.Parameters.AddWithValue("@Designation", employee.Designation);
                cmd.Parameters.AddWithValue("@Department", employee.Department);
                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    employeeAdded = true;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return employeeAdded;
        }

        public bool UpdateEmployee(Employee employee)
        {
            bool EmpoyeeUpdated = false;

            try
            {
                cmd = new SqlCommand("UpdateEmployee_4315", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", employee.Id);
                cmd.Parameters.AddWithValue("@Name", employee.Name);
                cmd.Parameters.AddWithValue("@Designation", employee.Designation);
                cmd.Parameters.AddWithValue("@Department", employee.Department);
                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    EmpoyeeUpdated = true;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return EmpoyeeUpdated;
        }

        public bool DeleteEmployee(int EmployeeID)
        {
            bool employeeDeleted = false;

            try
            {
                cmd = new SqlCommand("DeleteEmployee_4315", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", EmployeeID);

                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    employeeDeleted = true;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return employeeDeleted;
        }

        public Employee SearchEmployee(int id)
        {
            Employee employee = null;

            try
            {
                cmd = new SqlCommand("SelectEmployee_4315", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);

                conn.Open();
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    employee = new Employee();
                    employee.Id = dr.GetInt32(0);
                    employee.Name = dr.GetString(1);
                    employee.Designation = dr.GetInt32(2);
                    employee.Department = dr.GetInt32(3);
                }
            }
            catch (System.Exception ex)
            {

                throw ex;
            }
            finally
            {
                dr.Close();
                conn.Close();
            }

            return employee;
        }

        public List<Employee> ShowEmployee()
        {
            List<Employee> employeeList = null;

            try
            {
                cmd = new SqlCommand("SelectEmployees_4315", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    employeeList = new List<Employee>();

                    while (dr.Read())
                    {
                        Employee e = new Employee();
                        e.Id = dr.GetInt32(0);
                        e.Name = dr.GetString(1).ToString();
                        e.Designation = dr.GetInt32(2);
                        e.Department = dr.GetInt32(3);

                        employeeList.Add(e);
                    }
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                conn.Close();
            }

            return employeeList;
        }


    }
}
