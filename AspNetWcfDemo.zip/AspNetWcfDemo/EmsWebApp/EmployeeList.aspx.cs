﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmsWebApp.EmployeeServiceReference;

namespace EmsWebApp
{
    public partial class EmployeeList : System.Web.UI.Page
    {
        EmployeeServiceClient client = new EmployeeServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                List<Employee> elist = client.ShowEmployee().ToList();
                GridView1.DataSource = elist.ToList();
                GridView1.DataBind();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}