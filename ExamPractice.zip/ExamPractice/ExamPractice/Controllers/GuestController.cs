﻿using ExamPractice.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using Microsoft.Azure;

namespace ExamPractice.Controllers
{
    public class GuestController : ApiController
    {
        static CloudStorageAccount storageAccount;
        static CloudTableClient tableClient;
        static CloudTable table;

        public IEnumerable<GuestEntity> GetAll()
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("guests");

            List<GuestEntity> guest = new List<GuestEntity>();
            TableQuery<GuestEntity> query = new TableQuery<GuestEntity>();
            foreach (GuestEntity entity in table.ExecuteQuery(query))
            {

                GuestEntity g = new GuestEntity(entity.PartitionKey, entity.RowKey);

                g.GuestNo = entity.GuestNo;
                g.Name = entity.Name;
                g.GuestCity = entity.GuestCity;
                g.ContactNumber = entity.ContactNumber;


                guest.Add(g);
            }
            return guest;
        }

        public void Post(GuestEntity guest)
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("guests");
            TableOperation insertOperation = TableOperation.Insert(guest);
            table.Execute(insertOperation);
        }

        public GuestEntity GetbyID(string pk, string rk)
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("guests");

            GuestEntity guest = null;
            TableOperation op = TableOperation.Retrieve<GuestEntity>(pk, rk);
            TableResult tr = table.Execute(op);
            if (tr.Result != null)
            {
                guest = tr.Result as GuestEntity;
            }
            return guest;
        }

        public void DeleteGuestEntity(string pk,string rk)
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("guests");

            GuestEntity guest = null;
            TableOperation op = TableOperation.Retrieve<GuestEntity>(pk, rk);
            TableResult tr = table.Execute(op);
            if (tr.Result != null)
            {
                guest = tr.Result as GuestEntity;
                op = TableOperation.Delete(guest);
                tr = table.Execute(op);
            }
        }

        public void Put(GuestEntity guest)
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("guests");

            TableOperation op = TableOperation.Replace(guest);
            table.Execute(op);
           
        }
    }
}
