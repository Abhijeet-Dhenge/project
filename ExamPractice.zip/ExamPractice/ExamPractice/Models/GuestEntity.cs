﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamPractice.Models
{
    public class GuestEntity : TableEntity
    {
        public string Name { get; set; }

        public string ContactNumber { get; set; }

        public string GuestNo { get; set; }

        public string GuestCity { get; set; }

        public GuestEntity() { }

        public GuestEntity(string partitionKey, string rowKey)
        {
            this.PartitionKey = partitionKey;
            this.RowKey = rowKey;
        }
    }
}