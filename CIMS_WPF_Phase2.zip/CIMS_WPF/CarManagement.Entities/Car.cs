﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Entities
{
    public class Car
    {
        
        public int Id { get; set; }

        
        public string Model { get; set; }
        
        
        public int ManufacturerId { get; set; }

        
        public int TypeId { get; set; }

        public string Engine { get; set; }

        public int BHP { get; set; }

        
        public int TransmissionId { get; set; }

       
        public int Mileage { get; set; }

        
        public int Seat { get; set; }

        
        public string AirBagDetails { get; set; }

        
        public int BootSpace { get; set; }

        
        public float Price { get; set; }
    }
}
