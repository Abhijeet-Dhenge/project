﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarManagement.Entities;
using CarManagement.Exception;


namespace CarManagement.DataAccessLayer
{
    public class CarDAL
    {
        public static bool AddCarDAL(Car newCar)
        {
            bool carAdded = false;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "InsertCar_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = newCar.Model;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ManufacturerId";
                param.DbType = DbType.Int32;
                param.Value = newCar.ManufacturerId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@TypeId";
                param.DbType = DbType.Int32;
                param.Value = newCar.TypeId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Engine";
                param.DbType = DbType.String;
                param.Value = newCar.Engine;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BHP";
                param.DbType = DbType.Int32;
                param.Value = newCar.TransmissionId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Mileage";
                param.DbType = DbType.Int32;
                param.Value = newCar.Mileage;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Seat";
                param.DbType = DbType.Int32;
                param.Value = newCar.Seat;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@AirBagDetails";
                param.DbType = DbType.String;
                param.Value = newCar.AirBagDetails;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BootSpace";
                param.DbType = DbType.Int32;
                param.Value = newCar.BootSpace;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Price";
                param.DbType = DbType.Decimal;
                param.Value = newCar.Price;
                command.Parameters.Add(param);

                int affectedRows = CarConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    carAdded = true;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carAdded;
        }

        public static bool UpdateCarDAL(Car updateCar)
        {
            bool carUpdated = false;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "UpdateCar_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = updateCar.Model;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ManufacturerId";
                param.DbType = DbType.Int32;
                param.Value = updateCar.ManufacturerId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@TypeId";
                param.DbType = DbType.Int32;
                param.Value = updateCar.TypeId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Engine";
                param.DbType = DbType.String;
                param.Value = updateCar.Engine;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BHP";
                param.DbType = DbType.Int32;
                param.Value = updateCar.TransmissionId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Mileage";
                param.DbType = DbType.Int32;
                param.Value = updateCar.Mileage;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Seat";
                param.DbType = DbType.Int32;
                param.Value = updateCar.Seat;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@AirBagDetails";
                param.DbType = DbType.String;
                param.Value = updateCar.AirBagDetails;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BootSpace";
                param.DbType = DbType.Int32;
                param.Value = updateCar.BootSpace;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Price";
                param.DbType = DbType.Decimal;
                param.Value = updateCar.Price;
                command.Parameters.Add(param);

                int affectedRows = CarConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    carUpdated = true;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carUpdated;
        }

        public static bool RemoveCarDAL(string deleteCarModel)
        {
            bool carDeleted = false;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "DeleteCar_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = deleteCarModel;
                command.Parameters.Add(param);

                int affectedRows = CarConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    carDeleted = true;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carDeleted;
        }

        public static List<Car> SearchCarByManufacturer(int searchManufacturerId)
        {
            List<Car> searchedCar = null;

            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectCarByManufacturer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ManufacturerId";
                param.DbType = DbType.Int32;
                param.Value = searchManufacturerId;
                command.Parameters.Add(param);

                DataTable dataTable = CarConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchedCar = new List<Car>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Car car = new Car();
                        car.Model = (string)dataTable.Rows[rowCounter][0];
                        car.Engine = (string)dataTable.Rows[rowCounter][1];
                        car.BHP = (int)dataTable.Rows[rowCounter][2];
                        car.Seat = (int)dataTable.Rows[rowCounter][3];
                        car.AirBagDetails = (string)dataTable.Rows[rowCounter][4];
                        car.Price = (float)dataTable.Rows[rowCounter][5];
                        searchedCar.Add(car);
                    }
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCar;
        }

        public static Car SearchCarByModel(string searchModel)
        {
            Car searchedCar = null;

            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectCarByModel";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = searchModel;
                command.Parameters.Add(param);

                DataTable dataTable = CarConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchedCar = new Car();
                    Car car = new Car();
                    car.Model = (string)dataTable.Rows[0][0];
                    car.Engine = (string)dataTable.Rows[0][1];
                    car.BHP = (int)dataTable.Rows[0][2];
                    car.Seat = (int)dataTable.Rows[0][3];
                    car.AirBagDetails = (string)dataTable.Rows[0][4];
                    car.Price = (float)dataTable.Rows[0][5];
                        
                    
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCar;
        }

        public DataTable GetManufacturerDAL()
        {
            DataTable ManufacturerList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectManufacturer";

                ManufacturerList = CarConnection.ExecuteSelectCommand(command);
            }
            catch (DbException ex)
            {
                throw new CarException(ex.Message);
            }
            return ManufacturerList;
        }

        public DataTable GetCarTypeDAL()
        {
            DataTable CarTypeList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectCarType";

                CarTypeList = CarConnection.ExecuteSelectCommand(command);
            }
            catch (DbException ex)
            {
                throw new CarException(ex.Message);
            }
            return CarTypeList;
        }

        public DataTable GetCarTransmissionTypeDAL()
        {
            DataTable TransmissionTypeList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectTransmissionType";

                TransmissionTypeList = CarConnection.ExecuteSelectCommand(command);
            }
            catch (DbException ex)
            {
                throw new CarException(ex.Message);
            }
            return TransmissionTypeList;
        }

    }


}
