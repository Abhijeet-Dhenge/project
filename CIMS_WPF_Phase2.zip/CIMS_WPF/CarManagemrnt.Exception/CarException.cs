﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Exception
{
    public class CarException : ApplicationException
    {
        public CarException()
        {
        }

        public CarException(string message) : base(message)
        {
        }

        public CarException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected CarException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
