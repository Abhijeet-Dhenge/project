﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMS.Entities;
using CIMS.BussinessLayer;
using CIMS.Exceptions;

namespace CIMS
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddCar();
                        break;
                    case 2:
                        ListAllCars();
                        break;
                    case 3:
                        SearchCarByModel();
                        break;
                    case 4:
                        ModifyCar();
                        break;
                    case 5:
                        DeleteCar();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Car Information Management System***********");
            Console.WriteLine("1. Add Car");
            Console.WriteLine("2. List All Car");
            Console.WriteLine("3. Search Car By Model");
            Console.WriteLine("4. Modify Car Details");
            Console.WriteLine("5. Delete Car");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");

        }

        private static void AddCar()
        {
            try
            {
                CAR newCar = new CAR();
                Console.WriteLine("Enter Car Manufacturer");
                newCar.Manufacturer = Console.ReadLine();
                Console.WriteLine("Enter Car Model");
                newCar.Model = Console.ReadLine();
                Console.WriteLine("Enter Type of Car i.e Hatchback/Sedan/SUV");
                newCar.Type = Console.ReadLine();
                Console.WriteLine("Enter Engine Specification for eg. 1.1L or 1.5L etc.");
                newCar.Engine = Console.ReadLine();
                Console.WriteLine("Enter Engine Break Horse Power and it should be number only");
                newCar.Bhp = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Transmission Type i.e Manual or Automatic");
                newCar.Transmission = Console.ReadLine();
                Console.WriteLine("Enter Mileage in Km/ltr");
                newCar.Mileage = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Number of Seats");
                newCar.Seat = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Whether Car is Having Air Bags ?-Yes/No");
                newCar.AirBagDetails = Console.ReadLine();
                Console.WriteLine("Enter BootSpace");
                newCar.BootSpace = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Price of the Car");
                newCar.Price = Convert.ToInt32(Console.ReadLine());
                bool carAdded = CarBL.AddCarBL(newCar);
                if(carAdded)
                {
                    Console.WriteLine("Car Added");
                }
                else
                {
                    Console.WriteLine("Car not Added");
                }
            }
            catch(CarException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllCars()
        {
            try
            {
                List<CAR> carlist = CarBL.GetAllCars();
                if (carlist != null)
                {
                    Console.WriteLine("**************************************************************");
                    Console.WriteLine("Manufacturer\t\tModel\t\tEngine\t\tTransmission\t\tPrice");
                    Console.WriteLine("**************************************************************");
                    foreach (CAR car in carlist)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", car.Manufacturer, car.Model, car.Engine, car.Transmission, car.Price);
                        Console.WriteLine("------------------------------------------------------------------------------------------------------");

                    }
                }
                else
                {
                    Console.WriteLine("No Car Details Available");
                }
            }
            catch(CarException ex)
            {
                Console.WriteLine(ex.Message);

            }
        } 

        private static void SearchCarByModel()
        {
            try
            {
                string CarModel;
                Console.WriteLine("Enter Car Model");
                CarModel = Console.ReadLine();
                CAR searchCar = CarBL.SearchCarBL(CarModel);
                if(searchCar != null)
                {
                    Console.WriteLine("**************************************************************");
                    Console.WriteLine("Manufacturer\t\tModel\t\tEngine\t\tTransmission\t\tPrice");
                    Console.WriteLine("**************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", searchCar.Manufacturer, searchCar.Model, searchCar.Engine, searchCar.Transmission, searchCar.Price);
                    Console.WriteLine("------------------------------------------------------------------------------------------------------");                    
                }
                else
                {
                    Console.WriteLine("No Car Details Found");
                }
            }
            catch(CarException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ModifyCar()
        {
            try
            {
                string carModel;
                Console.WriteLine("Enter Car Model to Modify the Car Details");
                carModel = Console.ReadLine();
                CAR modifiedCar = CarBL.SearchCarBL(carModel);
                if(modifiedCar != null)
                {
                    Console.WriteLine("Modify Engine Specification");
                    modifiedCar.Engine = Console.ReadLine();
                    Console.WriteLine("Modify Engine BHP");
                    modifiedCar.Bhp = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Modify Price");
                    modifiedCar.Price = Convert.ToInt32(Console.ReadLine());
                    bool carUpdated = CarBL.UpdateCarBL(modifiedCar);
                    if(carUpdated)
                    {
                        Console.WriteLine("Car Details Modified");
                    }
                    else
                    {
                        Console.WriteLine("No Car Details Modified");
                    }
                }
                else
                {
                    Console.WriteLine("No Car Details Available");
                }
            }
            catch(CarException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }  

        private static void DeleteCar()
        {
            try
            {
                string carModel;
                Console.WriteLine("Enter Car Model to Delete");
                carModel = Console.ReadLine();
                CAR deleteCar = CarBL.SearchCarBL(carModel);
                if(deleteCar != null)
                {
                    bool cardeleted = CarBL.DeleteCarBL(carModel);
                    if(cardeleted)
                    {
                        Console.WriteLine("Car Deleted");
                    }
                    else
                    {
                        Console.WriteLine("Car Not Deleted");
                    }
                }
                else
                {
                    Console.WriteLine("No Car Details Available");
                }
            }
            catch(CarException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


    }
}
