﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btndisplay3_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database = Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
            SqlCommand sqlcmd = new SqlCommand("Select * from Aritra_46003367.EMP", sqlcon);
            sqlcon.Open();
            SqlDataReader sqldr = sqlcmd.ExecuteReader();
            while (sqldr.Read())
            {
                LstEmp.Items.Add(sqldr.GetInt32(0) + "" + sqldr.GetString(1) + "" + sqldr.GetInt32(3));
            }
            sqldr.Close();
            sqlcon.Close();
        }
    }
}
