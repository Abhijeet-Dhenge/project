﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class ListEmployee : Form
    {
        SqlConnection sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database = Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
        public ListEmployee()
        {
            InitializeComponent();
        }

        private void btnGetEmployees_Click(object sender, EventArgs e)
        {
            
            SqlCommand sqlcmd = new SqlCommand("spaGetEmployees", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcon.Open();
            SqlDataReader sqldr = sqlcmd.ExecuteReader();
            while (sqldr.Read())
            {
                listBox1.Items.Add(sqldr.GetInt32(0) + "" + sqldr.GetString(1) + "" + sqldr.GetInt32(2));
            }
            sqldr.Close();
            sqlcon.Close();

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnbyId_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("spaGetEmployeebyDeptid", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader sqldr;
            SqlParameter p1 = new SqlParameter();
            p1.ParameterName = "@deptid";
            p1.Value = txtdeptid.Text;
            sqlcmd.Parameters.Add(p1);
            sqlcon.Open();
            sqldr = sqlcmd.ExecuteReader();
            listEmpid.Items.Clear();
            while(sqldr.Read())
            {
                listEmpid.Items.Add(sqldr.GetInt32(0) + "  " + sqldr.GetString(1) + "  " + sqldr.GetInt32(2) + "  " + sqldr.GetInt32(3));
            }
            sqldr.Close();
            sqlcon.Close();
        }
    }
}
