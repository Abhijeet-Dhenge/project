﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {
        SqlConnection sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database = Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
        public Form6()
        {
            InitializeComponent();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("spaGetEmpCount1", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter();
            p1.ParameterName = "@deptid";
            p1.Value = txtdptid.Text;
            p1.Direction = ParameterDirection.Input;

            SqlParameter p2 = new SqlParameter();
            p2.ParameterName = "@empcount";
            p2.Size = 10;
            p2.Direction = ParameterDirection.Output;

            sqlcmd.Parameters.Add(p1);
            sqlcmd.Parameters.Add(p2);

            sqlcon.Open();
            sqlcmd.ExecuteScalar();
            string ecount = (string)sqlcmd.Parameters["@empcount"].Value;
            sqlcon.Close();
            MessageBox.Show(ecount);

        }
    }
}
