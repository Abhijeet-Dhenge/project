﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class Form8 : Form
    {
        DataSet ds;
        SqlDataAdapter da;
        public Form8()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            string connstring = ConfigurationManager.ConnectionStrings["constr"].ToString();
            SqlConnection sqlcon = new SqlConnection(connstring);
            SqlDataAdapter da = new SqlDataAdapter("Select * from Abhijeet_46004315.EMP", sqlcon);
            ds = new DataSet();
            da.Fill(ds, "Abhijeet_46004315.EMP");
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow row = ds.Tables["Abhijeet_46004315.EMP"].NewRow();
                row["EMPNO"] = txtEmpNo.Text;
                row["EMPNAME"] = txtEmpName.Text;
                row["JOB"] = txtjob.Text;
                row["MGR"] = txtMgrNo;
                row["HIREDATE"] = txtHiredate;
                row["SAL"] = txtSal;
                row["COMM"] = txtComm;
                row["DEPTNO"] = txtDptNo;

                ds.Tables["Abhijeet_46004315.EMP"].Rows.Add(row);
                MessageBox.Show("Current Row Status : " + row.RowState.ToString());

                int result = da.Update(ds, "Abhijeet_46004315.EMP");

                if (result > 0)
                {
                    MessageBox.Show("Employee successfully added.");
                }
                else
                    MessageBox.Show("Failed to add employee.");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
