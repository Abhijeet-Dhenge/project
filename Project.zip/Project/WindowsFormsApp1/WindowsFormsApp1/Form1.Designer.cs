﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btndisplay3 = new System.Windows.Forms.Button();
            this.LstEmp = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btndisplay3
            // 
            this.btndisplay3.Location = new System.Drawing.Point(168, 61);
            this.btndisplay3.Name = "btndisplay3";
            this.btndisplay3.Size = new System.Drawing.Size(75, 23);
            this.btndisplay3.TabIndex = 0;
            this.btndisplay3.Text = "Display";
            this.btndisplay3.UseVisualStyleBackColor = true;
            this.btndisplay3.Click += new System.EventHandler(this.btndisplay3_Click);
            // 
            // LstEmp
            // 
            this.LstEmp.FormattingEnabled = true;
            this.LstEmp.Location = new System.Drawing.Point(12, 100);
            this.LstEmp.Name = "LstEmp";
            this.LstEmp.Size = new System.Drawing.Size(413, 303);
            this.LstEmp.TabIndex = 1;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(496, 446);
            this.Controls.Add(this.LstEmp);
            this.Controls.Add(this.btndisplay3);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button btndisplay2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button btndisplay3;
        private System.Windows.Forms.ListBox LstEmp;
    }
}

