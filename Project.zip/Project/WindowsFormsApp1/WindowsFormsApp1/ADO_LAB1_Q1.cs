﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class ADO_LAB1_Q1 : Form
    {
        SqlConnection sqlcon;
        public ADO_LAB1_Q1()
        {
            InitializeComponent();
        }

        private void ADO_LAB1_Q1_Load(object sender, EventArgs e)
        {
            sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database = Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
            sqlcon.Open();
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            try
            {
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById_46004315", sqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                //define procedure parameter
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);
                //assign parameter value
                cmd.Parameters["@eno"].Value = int.Parse(txtEmployeeno.Text);
                //execute
                dreader = cmd.ExecuteReader();
                //if employee record found
                if (dreader.Read())
                {
                    txtEmployeeName.Text = dreader["empname"].ToString();
                    txtSalary.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P")
                        rdpayroll.Checked = true;
                    else
                        rdconsultant.Checked = true;
                }
                else
                {
                    btnNew_Click(btnNew, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
           
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtEmployeeno.Text = "";
            txtEmployeeName.Text = "";
            txtSalary.Text = "";
            txtEmployeeno.Focus();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            try
            {
                //The Insert DML to add employee record
                SqlCommand cmd = new SqlCommand
                ("insert into employee_46004315 values(@eno,@enm,@esal,@etyp)", sqlcon);
                //The Parameters
                cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);
                //Assigning Values to parameters
                cmd.Parameters["@eno"].Value = txtEmployeeno.Text;
                cmd.Parameters["@enm"].Value = txtEmployeeName.Text;
                cmd.Parameters["@esal"].Value = txtSalary.Text;
                cmd.Parameters["@etyp"].Value = rdpayroll.Checked == true ? "P" : "C";
                //Execute Insert ....
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Delete from employee_46004315 where EMPNO=@eno", sqlcon);
            cmd.Parameters.Add("@eno", SqlDbType.Int);
            cmd.Parameters["@eno"].Value = txtEmployeeno.Text;
            int c = cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted");
        }
    }
    }

