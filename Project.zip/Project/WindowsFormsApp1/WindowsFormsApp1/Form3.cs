﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        SqlConnection sqlcon;
        string sqlConnectString = "Server=NDAMSSQL\\SQLILEARN;Database = Training_13Aug19_Pune;User Id=sqluser;Password=sqluser";
        public Form3()
        {
            InitializeComponent();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            string sqlselect = "SELECT max(sal) from Abhijeet_46004315.EMP";
            sqlcon = new SqlConnection(sqlConnectString);
            SqlCommand cmdQuery = new SqlCommand(sqlselect);
            cmdQuery.Connection = sqlcon;
            sqlcon.Open();

            int maxsal = Convert.ToInt32(cmdQuery.ExecuteScalar());
            sqlcon.Close();
            MessageBox.Show("Maximum Salary =" + maxsal);

        }
    }
}
