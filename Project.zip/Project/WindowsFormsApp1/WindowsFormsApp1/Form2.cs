﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    
    public partial class Form2 : Form
    {
        SqlConnection sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database = Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
        public Form2()
        {

            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("Insert into Abhijeet_46004315.EMP values(1, 'Abhijeet','Engg',7349, '5/20/1980 12:00:00 AM',1600,300,30)",sqlcon);
            sqlcon.Open();
            int c = sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Record Inserted");
            sqlcon.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("Update Abhijeet_46004315.EMP set Sal=50000 where EMPNO=1", sqlcon);
            sqlcon.Open();
            int c = sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Record Updated");
            sqlcon.Close();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("Delete from Abhijeet_46004315.EMP where EMPNO=1", sqlcon);
            sqlcon.Open();
            int c = sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted");
            sqlcon.Close();

        }
    }
}
