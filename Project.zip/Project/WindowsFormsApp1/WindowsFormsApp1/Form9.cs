﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form9 : Form
    {
        SqlConnection sqlcon;

        SqlDataAdapter adapter;
        SqlCommandBuilder builder;
        DataSet ds;
        DataRow drow;
        
        public Form9()
        {
            InitializeComponent();
        }

        public void ShowDetails()
        {
            adapter.Fill(ds, "Abhijeet_46004315.EMP");
            drow = ds.Tables[0].Rows.Find(txtEmpNo.Text);

            txtEmpName.Text = drow[1].ToString();
            txtjob.Text = drow[2].ToString();
            txtMgrNo.Text = drow[3].ToString();
            txtHiredate.Text = drow[4].ToString();
            txtSal.Text = drow[5].ToString();
            txtComm.Text = drow[6].ToString();
            txtDptNo.Text = drow[7].ToString();


        }

        private void txtUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}
