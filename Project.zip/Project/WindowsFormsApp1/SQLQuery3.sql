create table employee_46004315
( empno int primary key,
empname varchar(50) not null,
empsal numeric(10,2) check(empsal >= 25000) ,
emptype varchar(1) check(emptype in('C','P'))
)
go
create proc GetEmployeeById_46004315
(
@eno int
)
as
select * from employee_46004315 where empno = @eno
go