﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using MVCApplication.Models;

namespace MVCApplication.Models
{
    public class EmployeeMetadata
    {

        [Required]
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        
        public int Designation { get; set; }
        [Required]
        
        public int Department { get; set; }

        
        public virtual Department Department1 { get; set; }

        [Display(Name = "Designation")]
        public virtual Designation Designation1 { get; set; }
    }
}