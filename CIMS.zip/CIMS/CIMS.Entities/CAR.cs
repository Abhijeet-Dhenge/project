﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS.Entities
{
    public class CAR
    {
        private string MANUFACTURER;

        public string Manufacturer
        {
            get { return MANUFACTURER; }
            set { MANUFACTURER = value; }
        }

        private string MODEL;

        public string Model
        {
            get { return MODEL; }
            set { MODEL = value; }
        }

        private string TYPE;

        public string Type
        {
            get { return TYPE; }
            set { TYPE = value; }
        }

        private string ENGINE;

        public string Engine
        {
            get { return ENGINE; }
            set { ENGINE = value; }
        }

        private int BHP;

        public int Bhp
        {
            get { return BHP; }
            set { BHP = value; }
        }

        private string TRANSMISSION;

        public string Transmission
        {
            get { return TRANSMISSION; }
            set { TRANSMISSION = value; }
        }

        private int MILEAGE;

        public int Mileage
        {
            get { return MILEAGE; }
            set { MILEAGE = value; }
        }

        private int SEAT;

        public int Seat
        {
            get { return SEAT; }
            set { SEAT = value; }
        }

        private string AIRBAGDETAILS;

        public string AirBagDetails
        {
            get { return AIRBAGDETAILS; }
            set { AIRBAGDETAILS = value; }
        }

        private int BOOTSPACE;

        public int BootSpace
        {
            get { return BOOTSPACE; }
            set { BOOTSPACE = value; }
        }

        private int PRICE;

        public int Price
        {
            get { return PRICE; }
            set { PRICE = value; }
        }

        public CAR()
        {
            MANUFACTURER = string.Empty;
            MODEL = string.Empty;
            TYPE = string.Empty;
            BHP = 0;
            TRANSMISSION = string.Empty;
            MILEAGE = 0;
            SEAT = 0;
            AIRBAGDETAILS = string.Empty;
            BOOTSPACE = 0;
            PRICE = 0;
        }











    }
}
