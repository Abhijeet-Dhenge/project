﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMS.Exceptions;
using CIMS.Entities;

namespace CIMS.DataAccessLayer
{
    public class CarDAL
    {
        public static List<CAR> carlist = new List<CAR>();

        public static bool AddCarDAL(CAR newcar)
        {
            bool caradded = false;
            try
            {
                carlist.Add(newcar);
                caradded = true;
            }
            catch(SystemException ex)
            {
                throw new CarException(ex.Message);
            }
            return caradded;
        }

        public static CAR SearchCarDAL(string CarName)
        {
            CAR SearchCar = null;
            try
            {
                SearchCar = carlist.Find(car => car.Model.Equals(CarName, StringComparison.OrdinalIgnoreCase));
            }
            catch(SystemException ex)
            {
                throw new CarException(ex.Message);
            }
            return SearchCar;
        }

        public static bool UpdateCarDAL(CAR UpdateCar)
        {
            bool CarUpdated = false;
            try
            {
                for(int i = 0; i < carlist.Count();i++)
                {
                    if(carlist[i].Manufacturer.Equals(UpdateCar.Manufacturer,StringComparison.OrdinalIgnoreCase) && carlist[i].Model.Equals(UpdateCar.Model,StringComparison.OrdinalIgnoreCase))
                    {
                        UpdateCar.Manufacturer = carlist[i].Manufacturer;
                        UpdateCar.Model = carlist[i].Model;
                        UpdateCar.Type = carlist[i].Type;
                        UpdateCar.Engine = carlist[i].Engine;
                        UpdateCar.Bhp = carlist[i].Bhp;
                        UpdateCar.Transmission = carlist[i].Transmission;
                        UpdateCar.Mileage = carlist[i].Mileage;
                        UpdateCar.Seat = carlist[i].Seat;
                        UpdateCar.AirBagDetails = carlist[i].AirBagDetails;
                        UpdateCar.BootSpace = carlist[i].BootSpace;
                        UpdateCar.Price = carlist[i].Price;
                    }
                }
            }
            catch(SystemException ex)
            {
                throw new SystemException(ex.Message);
            }
            return CarUpdated;
        }

        public static bool DeleteCarDAL(string CarModel)
        {
            bool CarDeleted = false;
            try
            {
                CAR CarToDelete = carlist.Find(car => car.Model.Equals(CarModel, StringComparison.OrdinalIgnoreCase)); 

                if(CarToDelete != null)
                {
                    carlist.Remove(CarToDelete);
                    CarDeleted = true;
                }
            }
            catch(SystemException ex)
            {
                throw new CarException(ex.Message);
            }
            return CarDeleted;
        }

        public static List<CAR> GetAllCars()
        {
            return carlist;
        }

    }
}
