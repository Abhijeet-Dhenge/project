﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CIMS.DataAccessLayer;
using CIMS.Entities;
using CIMS.Exceptions;

namespace CIMS.BussinessLayer
{
    public class CarBL
    {
        private static bool ValidateCar(CAR car)
        {
            StringBuilder sb = new StringBuilder();
            bool ValidateCar = true;
            string pattern = "^[0-9]{1}.[0-9]{1}[L]{1}$";
            Match m = Regex.Match(car.Engine, pattern);
            if (car.Manufacturer.Length == 0 )
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Manufacturer Name Cannot be Empty");
            }
            if(car.Model.Length == 0)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Model Name Cannot be Empty");
            }
            if(car.Type.Equals("HatchBack",StringComparison.OrdinalIgnoreCase)==false && car.Type.Equals("Sedan", StringComparison.OrdinalIgnoreCase)==false && car.Types.Equals("SUV", StringComparison.OrdinalIgnoreCase)==false)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Type can be HatchBack or Sedan or SUV only.");
            }
            if(/*!m.Success*/ car.Engine.Length == 0)

            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Engine Specification should be of format 1.1L ");
            }
            if(/*!car.Bhp.GetType().Equals("Integer") ||*/ car.Bhp==0)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Bhp Should be Number and Greater than Zero");
            }
            if(car.Transmission.Equals("Automatic",StringComparison.OrdinalIgnoreCase)==false && car.Transmission.Equals("Manual", StringComparison.OrdinalIgnoreCase)==false)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Transmission Should be of Type Manual or Automatic");
            }
            if(/*!car.Seat.GetType().Equals("Integer")*/car.Seat ==0)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Seat Should be a Number");
            }
            if (/*!car.BootSpace.GetType().Equals("Integer")*/ car.BootSpace==0)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "BootSpace Should be a Number");
            }
            if (/*!car.Price.GetType().Equals("Integer")*/ car.Price==0)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Price Should be a Number");
            }
            if (/*!car.Price.GetType().Equals("Integer")*/ car.AirBagDetails.Length == 0)
            {
                ValidateCar = false;
                sb.Append(Environment.NewLine + "Air Bag Details Should Be Yes or No");
            }

            if(ValidateCar==false)
            {
                Console.WriteLine(sb.ToString());
            }
            return ValidateCar;
        }

        public static bool AddCarBL(CAR NewCar)
        {
            bool CarAdded = false;

            try
            {
                if(ValidateCar(NewCar))
                {
                    //CarDAL carDal = new CarDAL();
                    CarAdded = CarDAL.AddCarDAL(NewCar);

                }
            }
            catch(SystemException ex)
            {
                throw new CarException(ex.Message);
            }

            return CarAdded;
        }

        public static List<CAR> GetAllCars()
        {
            List<CAR> carlist = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                carlist = CarDAL.GetAllCars();
            }
            catch(CarException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return carlist;
        }

        public static CAR SearchCarBL(string searchCarModel)
        {
            CAR searchCAR = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                searchCAR = CarDAL.SearchCarDAL(searchCarModel);
            }
            catch(CarException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return searchCAR;
        }

        public static bool UpdateCarBL(CAR updateCar)
        {
            bool carUpdated = false;
            try
            {
                if(ValidateCar(updateCar))
                {
                    //CarDAL carDAL = new CarDAL();
                    carUpdated = CarDAL.UpdateCarDAL(updateCar);
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carUpdated;
        }

        public static bool DeleteCarBL(string deleteCarModel)
        {
            bool carDeleted = false;
            try
            {
                if (deleteCarModel != null)
                {
                    //CarDAL carDAL = new CarDAL();
                    carDeleted = CarDAL.DeleteCarDAL(deleteCarModel);
                }
                else
                {
                    throw new CarException("Invalid Car Model");
                }
            }
            catch(CarException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return carDeleted;
        }



    }
}
