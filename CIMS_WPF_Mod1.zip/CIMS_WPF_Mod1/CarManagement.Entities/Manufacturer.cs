﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.Entities
{
    class Manufacturer
    {
        public int ManufacturerId { get; set; }
        public string Name { get; set; }
        public string ContactNo { get; set; }
        public string RegisteredOffice { get; set; }
        public List<Car> Cars { get; set; }
    }
}
