﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarManagement.Entities
{
    public class carTypeAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {

            if (value.ToString() == "Hatchback" || value.ToString() == "Sedan" || value.ToString() == "SUV")
            {
                return ValidationResult.Success;
            }


            return new ValidationResult("Please enter a correct value");
        }
    }
    class CarType
    {

        public int TypeID { get; set; }
        public string Type { get; set; }
        public List<Car> Cars { get; set; }
    }
}
