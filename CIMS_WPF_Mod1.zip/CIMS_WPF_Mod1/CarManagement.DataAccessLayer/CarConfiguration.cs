﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace CarManagement.DataAccessLayer
{
    public class CarConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return CarConfiguration.providerName; }
            set { CarConfiguration.providerName = value; }
        }

        private static string connectionString;

        public static string ConnectionString
        {
            get { return CarConfiguration.connectionString; }
            set { CarConfiguration.connectionString = value; }
        }

        static CarConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["carConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["carConnection"].ConnectionString;

        }

    }
}
