﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CarManagement.BussinessLayer;
using CarManagement.Entities;
using CarManagement.Exception;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddCar.xaml
    /// </summary>
    public partial class AddCar : Page
    {
        public AddCar()
        {
            InitializeComponent();
            //txtID.Text = CarBL.ReturnCarIdBL().ToString() + " (Auto-generated)";
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            GetManuFacturerMethod();
            GetCarTypeMethod();
            GetTransmissionTypeMethod();
        }



        private void GetTransmissionTypeMethod()
        {
            try
            {
                DataTable TransmissionTypeList = CarBL.GetCarTransmissionTypeBL();
                if (TransmissionTypeList.Rows.Count > 0)
                {
                    cmbTransmissionType.ItemsSource = TransmissionTypeList.DefaultView;
                    cmbTransmissionType.SelectedValuePath = TransmissionTypeList.Columns[0].ToString();
                    cmbTransmissionType.DisplayMemberPath = TransmissionTypeList.Columns[1].ToString();
                }
                else
                {
                    MessageBox.Show("No data available.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetCarTypeMethod()
        {
            try
            {
                DataTable CarTypeList = CarBL.GetCarTypeBL();
                if (CarTypeList.Rows.Count > 0)
                {
                    cmbTransmissionType.ItemsSource = CarTypeList.DefaultView;
                    cmbTransmissionType.SelectedValuePath = CarTypeList.Columns[0].ToString();
                    cmbTransmissionType.DisplayMemberPath = CarTypeList.Columns[1].ToString();
                }
                else
                {
                    MessageBox.Show("No data available.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetManuFacturerMethod()
        {
            try
            {
                DataTable ManufacturerList = CarBL.GetManufacturerBL();
                if (ManufacturerList.Rows.Count > 0)
                {
                    cmbTransmissionType.ItemsSource = ManufacturerList.DefaultView;
                    cmbTransmissionType.SelectedValuePath = ManufacturerList.Columns[0].ToString();
                    cmbTransmissionType.DisplayMemberPath = ManufacturerList.Columns[1].ToString();
                }
                else
                {
                    MessageBox.Show("No data available.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Car newCar = new Car();
                newCar.Model = txtModel.Text;
                newCar.ManufacturerId = Convert.ToInt32(cmbManufacturer.SelectedValue);
                newCar.TypeId = Convert.ToInt32(cmbCarType.SelectedValue);
                newCar.Engine = txtEngine.Text;
                newCar.BHP = Convert.ToInt32(txtBHP.Text);
                newCar.TransmissionId = Convert.ToInt32(cmbTransmissionType.SelectedValue);
                newCar.Mileage = Convert.ToInt32(txtMileage.Text);
                newCar.Seat = Convert.ToInt32(txtSeat.Text);
                newCar.AirBagDetails = txtAirBag.Text;
                newCar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                newCar.Price = Convert.ToDecimal(txtPrice.Text);
                bool carAdded = CarBL.AddCarBL(newCar);
                if (carAdded)
                    MessageBox.Show("Car Added");
                else
                    MessageBox.Show("Car could not be Added");
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
