﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CarManagement.Entities;
using CarManagement.BussinessLayer;
using CarManagement.Exception;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new AddCar();
            
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSearchModel_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSearchManufacturer_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnModify_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
