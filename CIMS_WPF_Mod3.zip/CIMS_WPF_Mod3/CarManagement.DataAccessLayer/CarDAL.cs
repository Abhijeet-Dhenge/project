﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarManagement.Entities;
using CarManagement.Exception;


namespace CarManagement.DataAccessLayer
{
    public class CarDAL
    {
        static SqlConnection conn = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser");  //Connection String
        static SqlCommand cmd;     //Will be used to store and execute command
        static SqlDataReader dr;
        public static bool AddCarDAL(Car newCar)
        {
           
            bool carAdded = false;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "InsertCar_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = newCar.Model;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ManufacturerId";
                param.DbType = DbType.Int32;
                param.Value = newCar.ManufacturerId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@TypeId";
                param.DbType = DbType.Int32;
                param.Value = newCar.TypeId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@TransmissionId";
                param.DbType = DbType.Int32;
                param.Value = newCar.TransmissionId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Engine";
                param.DbType = DbType.String;
                param.Value = newCar.Engine;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BHP";
                param.DbType = DbType.Int32;
                param.Value = newCar.TransmissionId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Mileage";
                param.DbType = DbType.Int32;
                param.Value = newCar.Mileage;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Seat";
                param.DbType = DbType.Int32;
                param.Value = newCar.Seat;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@AirBagDetails";
                param.DbType = DbType.String;
                param.Value = newCar.AirBagDetails;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BootSpace";
                param.DbType = DbType.Int32;
                param.Value = newCar.BootSpace;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Price";
                param.DbType = DbType.Decimal;
                param.Value = newCar.Price;
                command.Parameters.Add(param);

                int affectedRows = CarConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    carAdded = true;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carAdded;
        }

        public static bool UpdateCarDAL(Car updateCar)
        {
            bool carUpdated = false;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "UpdateCar_4315";

                 DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = updateCar.Model;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ManufacturerId";
                param.DbType = DbType.Int32;
                param.Value = updateCar.ManufacturerId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@TransmissionId";
                param.DbType = DbType.Int32;
                param.Value = updateCar.TransmissionId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@TypeId";
                param.DbType = DbType.Int32;
                param.Value = updateCar.TypeId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Engine";
                param.DbType = DbType.String;
                param.Value = updateCar.Engine;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BHP";
                param.DbType = DbType.Int32;
                param.Value = updateCar.BHP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Mileage";
                param.DbType = DbType.Int32;
                param.Value = updateCar.Mileage;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Seat";
                param.DbType = DbType.Int32;
                param.Value = updateCar.Seat;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@AirBagDetails";
                param.DbType = DbType.String;
                param.Value = updateCar.AirBagDetails;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BootSpace";
                param.DbType = DbType.Int32;
                param.Value = updateCar.BootSpace;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Price";
                param.DbType = DbType.Decimal;
                param.Value = updateCar.Price;
                command.Parameters.Add(param);

                int affectedRows = CarConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    carUpdated = true;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carUpdated;
        }

        public static bool RemoveCarDAL(string deleteCarModel)
        {
            bool carDeleted = false;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "DeleteCar_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = deleteCarModel;
                command.Parameters.Add(param);

                int affectedRows = CarConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    carDeleted = true;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carDeleted;
        }

        public static List<Car> SearchCarByManufacturer(int searchManufacturerId)
        {
            List<Car> searchedCar = null;

            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectCarByManufacturer_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ManufacturerId";
                param.DbType = DbType.Int32;
                param.Value = searchManufacturerId;
                command.Parameters.Add(param);

                DataTable dataTable = CarConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchedCar = new List<Car>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Car car = new Car();
                        car.Id = (int)dataTable.Rows[rowCounter][0];
                        car.Model = (string)dataTable.Rows[rowCounter][1];
                        car.ManufacturerId = (int)dataTable.Rows[rowCounter][2];
                        car.TypeId = (int)dataTable.Rows[rowCounter][3];
                        car.Engine = (string)dataTable.Rows[rowCounter][4];
                        car.BHP = (int)dataTable.Rows[rowCounter][5];
                        car.TransmissionId = (int)dataTable.Rows[rowCounter][6];
                        car.Mileage = (int)dataTable.Rows[rowCounter][7];
                        car.Seat = (int)dataTable.Rows[rowCounter][8];
                        car.AirBagDetails = (string)dataTable.Rows[rowCounter][9];
                        car.BootSpace = (int)dataTable.Rows[rowCounter][10];
                        car.Price = (Decimal)dataTable.Rows[rowCounter][11];
                        searchedCar.Add(car);
                    }
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCar;
        }

        public static Car SearchCarByModel(string searchModel)
        {
            Car searchedCar = null;

            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectCarByModel_4315";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@Model";
                param.DbType = DbType.String;
                param.Value = searchModel;
                command.Parameters.Add(param);

                DataTable dataTable = CarConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchedCar = new Car();
                    // Car car = new Car();
                    searchedCar.Id = (int)dataTable.Rows[0][0];
                    searchedCar.Model = (string)dataTable.Rows[0][1];
                    searchedCar.ManufacturerId = (int)dataTable.Rows[0][2];
                    searchedCar.TypeId = (int)dataTable.Rows[0][3];
                    searchedCar.Engine = (string)dataTable.Rows[0][4];
                    searchedCar.BHP = (int)dataTable.Rows[0][5];
                    searchedCar.TransmissionId = (int)dataTable.Rows[0][6];
                    searchedCar.Mileage = (int)dataTable.Rows[0][7];
                    searchedCar.Seat = (int)dataTable.Rows[0][8];
                    searchedCar.AirBagDetails = (string)dataTable.Rows[0][9];
                    searchedCar.BootSpace = (int)dataTable.Rows[0][10];
                    searchedCar.Price = (Decimal)dataTable.Rows[0][11];


                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCar;
        }

        public static DataTable GetManufacturerDAL()
        {
            DataTable ManufacturerList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectManufacturer";

                ManufacturerList = CarConnection.ExecuteSelectCommand(command);
            }
            catch (DbException ex)
            {
                throw new CarException(ex.Message);
            }
            return ManufacturerList;
        }

        public static DataTable GetCarTypeDAL()
        {
            DataTable CarTypeList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectCarType_4315";

                CarTypeList = CarConnection.ExecuteSelectCommand(command);
            }
            catch (DbException ex)
            {
                throw new CarException(ex.Message);
            }
            return CarTypeList;
        }

        public static DataTable GetCarTransmissionTypeDAL()
        {
            DataTable TransmissionTypeList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectTransmissionType_4315";

                TransmissionTypeList = CarConnection.ExecuteSelectCommand(command);
            }
            catch (DbException ex)
            {
                throw new CarException(ex.Message);
            }
            return TransmissionTypeList;
        }

        public static int ReturnCarIdDAL()
        {

            DbCommand command = CarConnection.CreateCommand();
            command.CommandText = "ReturnCarID_4315";

            int carID = (int)CarConnection.ExecuteScalarCommand(command);

            return carID;
        }

        public static List<Manufacturer> GetManufacturerDAL1()       //To get the Category List
        {
            List<Manufacturer> categories = null;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser"))
                {
                    SqlCommand sqlCmd = new SqlCommand("SELECT * FROM Manufacturer_4315", sqlConnection);
                    sqlConnection.Open();
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    categories = new List<Manufacturer>();
                    while (sqlReader.Read())
                    {
                        Manufacturer category = new Manufacturer();
                        category.ManufacturerId = int.Parse(sqlReader["Id"].ToString());
                        category.Name = sqlReader["ManufacturerName"].ToString();
                        categories.Add(category);
                    }
                    sqlReader.Close();
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return categories;
        }

        public static List<CarType> GetCarTypeDAL1()       //To get the Category List 
        {
            List<CarType> categories = null;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser"))
                {
                    SqlCommand sqlCmd = new SqlCommand("SELECT * FROM CarType_4315", sqlConnection);
                    sqlConnection.Open();
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    categories = new List<CarType>();
                    while (sqlReader.Read())
                    {
                        CarType category = new CarType();
                        category.TypeID = int.Parse(sqlReader["Id"].ToString());
                        category.Type = sqlReader["CarType"].ToString();
                        categories.Add(category);
                    }
                    sqlReader.Close();
                } 
            }
            catch (CarException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return categories;
        }

        public static List<CarTransmissionType> GetCarTransmissionTypeDAL1()       //To get the Category List
        {
            List<CarTransmissionType> transmissiontype = null;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser"))
                {
                    SqlCommand sqlCmd = new SqlCommand("SELECT * FROM CarTransmissionType_4315", sqlConnection);
                    sqlConnection.Open();
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    transmissiontype = new List<CarTransmissionType>();
                    while (sqlReader.Read())
                    {
                        CarTransmissionType category3 = new CarTransmissionType();
                        category3.TransmissionId = int.Parse(sqlReader["Id"].ToString());
                        category3.Name = sqlReader["TransmissionName"].ToString();
                        transmissiontype.Add(category3);
                    }
                    sqlReader.Close();
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return transmissiontype;
        }

        public static List<Car> ListAllCustomersDAL()
        {
            List<Car> carList = null;
            try
            {
                DbCommand command = CarConnection.CreateCommand();
                command.CommandText = "SelectAllCars_4315";

                DataTable dataTable = CarConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    carList = new List<Car>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Car car = new Car();
                        car.Id = (int)dataTable.Rows[rowCounter][0];
                        car.Model = (string)dataTable.Rows[rowCounter][1];
                        car.ManufacturerId = (int)dataTable.Rows[rowCounter][2];
                        car.TypeId = (int)dataTable.Rows[rowCounter][3];
                        car.Engine = (string)dataTable.Rows[rowCounter][4];
                        car.BHP = (int)dataTable.Rows[rowCounter][5];
                        car.TransmissionId = (int)dataTable.Rows[rowCounter][6];
                        car.Mileage = (int)dataTable.Rows[rowCounter][7];
                        car.Seat = (int)dataTable.Rows[rowCounter][8];
                        car.AirBagDetails = (string)dataTable.Rows[rowCounter][9];
                        car.BootSpace = (int)dataTable.Rows[rowCounter][10];
                        car.Price = (Decimal)dataTable.Rows[rowCounter][11];
                        carList.Add(car);
                    }
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carList;
        }

    }


}
