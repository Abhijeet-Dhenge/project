﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarManagement.Entities
{

   public class CarType
    {

        public int TypeID { get; set; }
        public string Type { get; set; }
        //public List<Car> Cars { get; set; }
    }
}
