﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarManagement.Entities;
using CarManagement.BussinessLayer;
using CarManagement.Exception;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for SearchCarByModel.xaml
    /// </summary>
    public partial class SearchCarByModel : Window
    {
        public SearchCarByModel()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchModel;

                if (string.IsNullOrEmpty(txtModel.Text))
                {
                    MessageBox.Show("Customer ID cannot be null or empty");
                    txtEngine.Text = "";
                    txtBHP.Text = "";
                    txtMileage.Text = "";
                    txtSeat.Text = "";
                    txtPrice.Text = "";
                }
                else
                {
                    searchModel = txtModel.Text;
                    Car searchCar = CarBL.SearchCarByModelBL(searchModel);
                    if (searchCar != null)
                    {
                        txtEngine.Text = searchCar.Engine;
                        txtBHP.Text = searchCar.BHP.ToString();
                        txtMileage.Text = searchCar.Mileage.ToString();
                        txtSeat.Text = searchCar.Seat.ToString();
                        txtPrice.Text = searchCar.Price.ToString();

                    }
                    else
                    {
                        MessageBox.Show("No Customer details available");
                        txtEngine.Text = "";
                        txtBHP.Text = "";
                        txtMileage.Text = "";
                        txtSeat.Text = "";
                        txtPrice.Text = "";
                    }
                }


            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MainWindow.mainWin1.EnableAllButtons();
        }
    }
    }

