﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarManagement.Entities;
using CarManagement.Exception;
using CarManagement.BussinessLayer;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ViewCar.xaml
    /// </summary>
    public partial class ViewCar : Window
    {
        public ViewCar()
        {
            InitializeComponent();
            List<Car> carList = CarBL.ListAllCarsBLL();

            if (carList.Count > 0)
            {
                dgCars.HeadersVisibility = DataGridHeadersVisibility.All;
            }
            dgCars.ItemsSource = carList;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MainWindow.mainWin1.EnableAllButtons();
        }
    }
}
