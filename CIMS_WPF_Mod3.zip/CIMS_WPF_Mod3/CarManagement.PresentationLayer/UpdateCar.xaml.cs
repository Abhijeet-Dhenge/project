﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarManagement.Entities;
using CarManagement.Exception;
using CarManagement.BussinessLayer;
using System.Data;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for UpdateCar.xaml
    /// </summary>
    public partial class UpdateCar : Window
    {
        public UpdateCar()
        {
            InitializeComponent();
            List<Manufacturer> categeroies = CarBL.GetManufacturerBLL();
            foreach (var item in categeroies)
            {
                cmbManufacturer.Items.Add(item.Name);
            }

            List<CarType> categeroies2 = CarBL.GetCarTypeBLL();
            foreach (var item in categeroies2)
            {
                cmbCarType.Items.Add(item.Type);
            }

            List<CarTransmissionType> categeroies3 = CarBL.GetTransmissionTypeBLL();
            foreach (var item in categeroies3)
            {
                cmbTransmissionType.Items.Add(item.Name);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchCarModel;

                if (string.IsNullOrEmpty(txtModel.Text))
                {
                    MessageBox.Show("Customer ID cannot be null or empty");
                }
                else
                {
                    searchCarModel = txtModel.Text; ;
                    Car searchCar = CarBL.SearchCarByModelBL(searchCarModel);
                    if (searchCar != null)
                    {
                        //cmbManufacturer.SelectedIndex = searchCar.ManufacturerId;
                       // List<Manufacturer> categeroies = CarBL.GetManufacturerBLL();
                       // cmbManufacturer.DisplayMemberPath = categeroies[searchCar.ManufacturerId].ToString();
                       cmbManufacturer.SelectedValue = searchCar.ManufacturerId;
                        cmbCarType.SelectedValue = searchCar.TypeId;
                        txtEngine.Text = searchCar.Engine.ToString();
                        txtBHP.Text = searchCar.BHP.ToString();
                        cmbTransmissionType.SelectedValue = searchCar.TransmissionId;
                        txtMileage.Text = searchCar.Mileage.ToString();
                        txtSeat.Text = searchCar.Seat.ToString();
                        txtAirBagDetails.Text = searchCar.AirBagDetails.ToString();
                        txtBootSpace.Text = searchCar.BootSpace.ToString();
                        txtPrice.Text = searchCar.Price.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No Customer details available");
                    }
                }

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string updateCarModel = txtModel.Text;

                Car updatedCar = CarBL.SearchCarByModelBL(updateCarModel);

                if (updatedCar != null)
                {
                    updatedCar.ManufacturerId = Convert.ToInt32(cmbManufacturer.SelectedIndex) + 1;
                    updatedCar.TypeId = Convert.ToInt32(cmbCarType.SelectedIndex)+1;
                    string UEngine =  txtEngine.Text;
                    updatedCar.Engine = UEngine;
                    string bhp =  txtBHP.Text;
                    updatedCar.BHP = Convert.ToInt32(bhp);
                    updatedCar.TransmissionId = Convert.ToInt32(cmbTransmissionType.SelectedIndex)+1;
                    string mileage =  txtMileage.Text;
                    updatedCar.Mileage = Convert.ToInt32(mileage);
                    string seat =  txtSeat.Text;
                    updatedCar.Seat = Convert.ToInt32(seat);
                    string airbag =  txtAirBagDetails.Text;
                    updatedCar.AirBagDetails = airbag;
                    string boot =  txtBootSpace.Text;
                    updatedCar.BootSpace = Convert.ToInt32(boot);
                    string price =  txtPrice.Text;
                    updatedCar.Price = Convert.ToDecimal(price);

                    bool carUpdated = CarBL.UpdateCarBL(updatedCar);

                    if (carUpdated)
                    {
                        MessageBox.Show("Customer modified");
                        txtModel.Text = "";
                        cmbManufacturer.SelectedIndex = 0;
                        cmbCarType.SelectedIndex = 0;
                        txtEngine.Text = "";
                        txtBHP.Text = "";
                        cmbTransmissionType.SelectedIndex = 0;
                        txtMileage.Text = "";
                        txtSeat.Text = "";
                        txtAirBagDetails.Text = "";
                        txtBootSpace.Text = "";
                        txtPrice.Text = "";
                    }

                    else
                        MessageBox.Show("Customer could not be modified");
                }
                else
                {
                    MessageBox.Show("No Customer details available");
                }

            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void Window_Closed(object sender, EventArgs e)
        {
            MainWindow.mainWin1.EnableAllButtons();
        }

    }
}
