﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarManagement.BussinessLayer;
using CarManagement.Entities;
using CarManagement.Exception;
namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for CraeteCar.xaml
    /// </summary>
    public partial class CraeteCar : Window
    {
        public CraeteCar()
        {
            InitializeComponent();
            List<Manufacturer> categeroies = CarBL.GetManufacturerBLL();
            foreach (var item in categeroies)
            {
                cmbManufacturer.Items.Add(item.Name);
            }

            List<CarType> categeroies2 = CarBL.GetCarTypeBLL();
            foreach (var item in categeroies2)
            {
                cmbCarType.Items.Add(item.Type);
            }

            List<CarTransmissionType> categeroies3 = CarBL.GetTransmissionTypeBLL();
            foreach (var item in categeroies3)
            {
                cmbTransmissionType.Items.Add(item.Name);
            }


            //txtID.Text = CarBL.ReturnCarIdBL().ToString() + " (Auto-generated)"; //The List will be created from the database itself
        }



        

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Car newCar = new Car();
                newCar.Model = txtModel.Text;
                newCar.ManufacturerId = Convert.ToInt32(cmbManufacturer.SelectedIndex)+1;
                newCar.TypeId = Convert.ToInt32(cmbCarType.SelectedIndex)+1;
                newCar.Engine = txtEngine.Text;
                newCar.BHP = Convert.ToInt32(txtBHP.Text);
                newCar.TransmissionId = Convert.ToInt32(cmbTransmissionType.SelectedIndex)+1;
                newCar.Mileage = Convert.ToInt32(txtMileage.Text);
                newCar.Seat = Convert.ToInt32(txtSeat.Text);
                newCar.AirBagDetails = txtAirBag.Text;
                newCar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                newCar.Price = Convert.ToDecimal(txtPrice.Text);
                bool carAdded = CarBL.AddCarBL(newCar);
                if (carAdded)
                    MessageBox.Show("Car Added");
                else
                    MessageBox.Show("Car could not be Added");
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private  void Window_Loaded(object sender, ContextMenuEventArgs e)
        {
            //GetManuFacturerMethod();
           // GetCarTypeMethod();
            //GetTransmissionTypeMethod();
            
        }

        private void CmbManufacturer_ContextMenuClosing(object sender, ContextMenuEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MainWindow.mainWin1.EnableAllButtons();
        }
    }
}
