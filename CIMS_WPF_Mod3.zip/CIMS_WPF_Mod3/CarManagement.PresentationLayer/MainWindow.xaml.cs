﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CarManagement.Entities;
using CarManagement.BussinessLayer;
using CarManagement.Exception;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow mainWin1;
        public MainWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            mainWin1 = this;
        }

        public void EnableAllButtons()
        {
            btnCreate.IsEnabled = true;
            btnView.IsEnabled = true;
            btnSearchManufacturer.IsEnabled = true;
            btnSearchModel.IsEnabled = true;
            btnModify.IsEnabled = true;
            btnRemove.IsEnabled = true;
            btnExit.IsEnabled = true;
        }
        private void DisableAllButtons()
        {
            btnCreate.IsEnabled = false;
            btnView.IsEnabled = false;
            btnSearchManufacturer.IsEnabled = false;
            btnSearchModel.IsEnabled = false;
            btnModify.IsEnabled = false;
            btnRemove.IsEnabled = false;
            btnExit.IsEnabled = false;
        }
        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            CraeteCar car = new CraeteCar();
            car.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            car.Show();
            DisableAllButtons();

        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            ViewCar win2 = new ViewCar();
            win2.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win2.Show();
            DisableAllButtons();
        }

        private void BtnSearchModel_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByModel win4 = new SearchCarByModel();
            win4.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win4.Show();
            DisableAllButtons();

        }

        private void BtnSearchManufacturer_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByManufacturer win3 = new SearchCarByManufacturer();
            win3.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win3.Show();
            DisableAllButtons();
        }

        private void BtnModify_Click(object sender, RoutedEventArgs e)
        {
            UpdateCar win5 = new UpdateCar();
            win5.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win5.Show();
            DisableAllButtons();
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            RemoveCarByModel win6 = new RemoveCarByModel();
            win6.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win6.Show();
            DisableAllButtons();

        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
