﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarManagement.Entities;
using CarManagement.BussinessLayer;
using CarManagement.Exception;

namespace CarManagement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RemoveCarByModel.xaml
    /// </summary>
    public partial class RemoveCarByModel : Window
    {
        public RemoveCarByModel()
        {
            InitializeComponent();
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string deleteCarModel = txtModel.Text;

                Car deleteCar = CarBL.SearchCarByModelBL(deleteCarModel);

                if (deleteCar != null)
                {

                    bool carDeleted = CarBL.DeleteCarBL(deleteCarModel);

                    if (carDeleted)
                        MessageBox.Show("Customer removed");
                    else
                        MessageBox.Show("Customer could not be removed");
                }
                else
                {
                    MessageBox.Show("No Customer details removed");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
