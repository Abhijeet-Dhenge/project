﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OrsWebService.Models;


namespace OrsWebService.Controllers
{
    [RoutePrefix("api/Ors")]
    public class OrsController : ApiController
    {
        [HttpPost]
        [Route("RegisterJobSeeker")]
        public IHttpActionResult RegisterJobSeeker(JobSeekerPersInfo seeker)
        {
            try
            {
                OrsEntities entities = new OrsEntities();
                entities.JobSeekerPersInfoes.Add(new JobSeekerPersInfo()
                {
                    FirstName = seeker.FirstName,
                    LastName = seeker.LastName,
                    DOB = seeker.DOB,
                    EmailId = seeker.MobileNo,
                    MobileNo = seeker.MobileNo,
                    Gender = seeker.Gender,
                    Address1 = seeker.Address1,
                    City = seeker.City,

                    State1 = seeker.State1,
                    UserName = seeker.UserName,
                    Pwd = seeker.Pwd

                });
                entities.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return Ok();
        }

        [HttpPost]
        [Route("RegisterEmployer")]
        public IHttpActionResult RegisterEmployer(EmployerInfo employer)
        {
            try
            {
                OrsEntities entities = new OrsEntities();
                entities.EmployerInfoes.Add(new EmployerInfo()
                {
                    CompanyName = employer.CompanyName,
                    EmailId = employer.EmailId,
                    MobileNo = employer.MobileNo,
                    ContactPerson = employer.ContactPerson,
                    Website = employer.Website,
                    Address1 = employer.Address1,
                    City = employer.City,
                    State1 = employer.State1,
                    UserName = employer.UserName,
                    Pwd = employer.Pwd
                });
                entities.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return Ok();

        }
        [HttpGet]
        public JobSeekerPersInfo JobSeekerLogin(JobSeekerLogin login)
        {
            OrsEntities entities = new OrsEntities();
            var log = entities.JobSeekerPersInfoes.Where(x => x.UserName.Equals(login.UserName) && x.Pwd.Equals(login.Pwd));
            if(log !=null)
            {
                return log;
            }
        }
    }
}
