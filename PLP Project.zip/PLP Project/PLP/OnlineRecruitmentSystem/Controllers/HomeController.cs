﻿using OnlineRecruitmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace OnlineRecruitmentSystem.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Signup()
        {
            ViewBag.Message = "Sign up page.";

            return View();
        }
        [HttpPost]
        public ActionResult Signup(JobSeekerPersInfo seeker)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/RegisterJobSeeker");
            var regseeker = hc.PostAsJsonAsync<JobSeekerPersInfo>("", seeker);
            regseeker.Wait();
            TempData["SuccessMessage"] = "Saved Successfully";
            return RedirectToAction("Index");
        }
        
        public ActionResult Login()
        {
            ViewBag.Message = "Login page.";

            return View();
        }
        public ActionResult Admin()
        {
            ViewBag.Message = "Admin Login page.";

            return View();
        }
        public ActionResult Employer()
        {
            ViewBag.Message = "Employer signup page.";

            return View();
        }
        [HttpPost]
        public ActionResult Employer(EmployerInfo employer)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:60660/api/ors/RegisterEmployer");
            var regemployer = hc.PostAsJsonAsync<EmployerInfo>("",employer);
            regemployer.Wait();
            return RedirectToAction("Index");
        }

        public ActionResult EmployerLogin()
        {
            ViewBag.Message = "Employer Login page.";

            return View();
        }
        public ActionResult EducationalInfo()
        {
            ViewBag.Message = "Employer Login page.";

            return View();
        }

    }
}