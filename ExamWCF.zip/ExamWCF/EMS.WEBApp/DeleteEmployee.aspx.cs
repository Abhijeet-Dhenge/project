﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.WEBApp.EmployeeServiceReference;

namespace EMS.WEBApp
{
    public partial class DeleteEmployee : System.Web.UI.Page
    {
        EmployeeServiceClient client = new EmployeeServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            if (txtID.Text == string.Empty)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg", "alert('Please enter id')", true);
            }
            else
            {
                try
                {
                    int deleteId = Convert.ToInt32(txtID.Text);

                    bool status = client.DeleteEmployee(deleteId);

                    if (status)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "m3", "alert('Employee Details Deleted')", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "m6", "alert('Unable to delete employee')", true);
                    }
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "error3", "alert('" + ex.Message + "')", true);
                }

            }
        }
    }
}