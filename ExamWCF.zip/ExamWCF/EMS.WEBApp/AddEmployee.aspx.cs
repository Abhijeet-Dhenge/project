﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.WEBApp.EmployeeServiceReference;

namespace EMS.WEBApp
{
    public partial class AddEmployee : System.Web.UI.Page
    {
        EmployeeServiceClient client = new EmployeeServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                Employee employee = new Employee();

                employee.ID = Convert.ToInt32(txtID.Text);
                employee.Name = txtName.Text;
                employee.Designation = Convert.ToInt32(ddlDesignation.SelectedValue);
                employee.Department = Convert.ToInt32(ddlDepartment.SelectedValue);

                bool status = client.AddEmployee(employee);

                if (status)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "m1", "alert('Employee Details Added')", true);

                    txtID.Text = "";
                    txtName.Text = "";
                    ddlDesignation.SelectedValue = "";
                    ddlDepartment.SelectedValue = "";
                
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "error5", "alert('" + ex.Message + "')", true);
                //throw ex;
            }
        }
    }
}