﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.WEBApp.EmployeeServiceReference;

namespace EMS.WEBApp
{
    public partial class EmployeeList : System.Web.UI.Page
    {
        EmployeeServiceClient client = new EmployeeServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {

            List<Employee> employeelist = new List<Employee>();

            try
            {
                employeelist = client.ShowEmployee().ToList();

                GridView1.DataSource = employeelist.ToList();
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                lblerror.Text = ex.Message;
            }

        }
    }
}