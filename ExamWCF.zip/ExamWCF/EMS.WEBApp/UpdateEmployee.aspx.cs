﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.WEBApp.EmployeeServiceReference;

namespace EMS.WEBApp
{
    public partial class UpdateEmployee : System.Web.UI.Page
    {
        EmployeeServiceClient client = new EmployeeServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpdateEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                Employee employee = new Employee();
                employee.ID = Convert.ToInt32(txtID.Text);
                employee.Name = txtName.Text;
                employee.Designation = Convert.ToInt32(ddlDesig);
                employee.Department = Convert.ToInt32(ddlDept);

                bool status = client.UpdateEmployee(employee);

                if (status)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "m3", "alert('Employee Details Updated')", true);

                    txtID.Text = "";
                    txtName.Text = "";
                    ddlDesig.SelectedIndex = 0;
                    ddlDept.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "error1", "alert('" + ex.Message + "')", true);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtID.Text == string.Empty)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "m2", "alert('Please enter ID to search')", true);
            }
            else
            {
                try
                {
                    int searchId = Convert.ToInt32(txtID.Text);

                    Employee employee = client.SearchEmployee(searchId);

                    if (employee != null)
                    {
                        txtName.Text = employee.Name;
                        ddlDesig.SelectedValue = employee.Designation.ToString();
                        ddlDept.SelectedValue = employee.Department.ToString(); ;
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "m4", "alert('Employee not available')", true);
                    }
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "error1", "alert('" + ex.Message + "')", true);
                }
            }
        }
    }
}