﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.WEBApp.EmployeeServiceReference;

namespace EMS.WEBApp
{
    public partial class SearchEmployee : System.Web.UI.Page
    {
        EmployeeServiceClient client = new EmployeeServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            if (txtID.Text == string.Empty)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "msg1", "alert('Please enter ID')", true);
            }
            else
            {
                try
                {
                    int searchId = Convert.ToInt32(txtID.Text);

                    Employee employee = client.SearchEmployee(searchId);

                    if (employee != null)
                    {
                        List<Employee> blist = new List<Employee>();
                        blist.Add(employee);
                        DetailsView1.DataSource = blist.ToList();
                        DetailsView1.DataBind();
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "error4", "alert('Employee Not Available')", true);
                    }
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "error5", "alert('" + ex.Message + "')", true);
                }
            }
        }
    }
}