﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CarManagement.DataAccessLayer;
using CarManagement.Entities;
using CarManagement.Exception;

namespace CarManagement.BussinessLayer
{
    public class CarBL
    {
        private static bool ValidateCar(Car car)
        {
            StringBuilder sb = new StringBuilder();
            bool ValidateCar = true;
            string pattern = "^[0-9]{1}.[0-9]{1}[L]{1}$";
            Match m = Regex.Match(car.Engine, pattern);
            try
            {
                if (car.ManufacturerId == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Manufacturer Name Cannot be Empty");
                }
                if (car.Model.Length == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Model Name Cannot be Empty");
                }
                if (car.TypeId == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Type can be HatchBack or Sedan or SUV only.");
                }
                if (/*!m.Success*/ car.Engine.Length == 0)

                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Engine Specification should be of format 1.1L ");
                }
                if (/*!car.Bhp.GetType().Equals("Integer") ||*/ car.BHP == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Bhp Should be Number and Greater than Zero");
                }
                if (car.TransmissionId == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Transmission Should be of Type Manual or Automatic");
                }
                if (/*!car.Seat.GetType().Equals("Integer")*/car.Seat == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Seat Should be a Number");
                }
                if (/*!car.BootSpace.GetType().Equals("Integer")*/ car.BootSpace == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "BootSpace Should be a Number");
                }
                if (/*!car.Price.GetType().Equals("Integer")*/ car.Price == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Price Should be a Number");
                }
                if (/*!car.Price.GetType().Equals("Integer")*/ car.AirBagDetails.Length == 0)
                {
                    ValidateCar = false;
                    sb.Append(Environment.NewLine + "Air Bag Details Should Be Yes or No");
                }

                if (ValidateCar == false)
                {
                    Console.WriteLine(sb.ToString());
                }
            }
            catch(CarException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return ValidateCar;
        }

        public static bool AddCarBL(Car NewCar)
        {
            bool CarAdded = false;

            try
            {
                if (ValidateCar(NewCar))
                {
                    //CarDAL carDal = new CarDAL();
                    CarAdded = CarDAL.AddCarDAL(NewCar);

                }
            }
            catch (SystemException ex)
            {
                throw new CarException(ex.Message);
            }

            return CarAdded;
        }

        public static bool UpdateCarBL(Car updateCar)
        {
            bool carUpdated = false;
            try
            {
                if (ValidateCar(updateCar))
                {
                    //CarDAL carDAL = new CarDAL();
                    carUpdated = CarDAL.UpdateCarDAL(updateCar);
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carUpdated;
        }

        public static bool DeleteCarBL(string deleteCarModel)
        {
            bool carDeleted = false;
            try
            {
                if (deleteCarModel != null)
                {
                    //CarDAL carDAL = new CarDAL();
                    carDeleted = CarDAL.RemoveCarDAL(deleteCarModel);
                }
                else
                {
                    throw new CarException("Invalid Car Model");
                }
            }
            catch (CarException ex)
            {
                throw ex;

            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return carDeleted;
        }

        public static Car SearchCarByModelBL(string searchCarModel)
        {
            Car searchCAR = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                searchCAR = CarDAL.SearchCarByModel(searchCarModel);
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchCAR;
        }

        public static List<Car> SearchCarByManufacturerBL(int searchManufacturerId)
        {
            List<Car> searchCAR = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                searchCAR = CarDAL.SearchCarByManufacturer(searchManufacturerId);
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchCAR;
        }

        public static DataTable GetManufacturerBL()
        {
            DataTable ManufacturerList = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                ManufacturerList = CarDAL.GetManufacturerDAL();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return ManufacturerList;
        }

        public static DataTable GetCarTypeBL()
        {
            DataTable CarTypeList = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                CarTypeList = CarDAL.GetCarTypeDAL();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return CarTypeList;
        }

        public static DataTable GetCarTransmissionTypeBL()
        {
            DataTable TransmissionType = null;
            try
            {
                //CarDAL carDAL = new CarDAL();
                TransmissionType = CarDAL.GetCarTransmissionTypeDAL();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return TransmissionType;
        }

        //Wrapper method to Return Customer ID

        public static int ReturnCarIdBL()
        {
            int carID;

            try
            {
                carID = CarDAL.ReturnCarIdDAL();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return carID;
        }

        public static List<Manufacturer> GetManufacturerBLL()       //To get the Status List
        {
            List<Manufacturer> manufacturer = null;

            try
            {
                manufacturer = CarDAL.GetManufacturerDAL1();
            }
            catch (CarException ex)
            {
                throw ex;
            }

            return manufacturer;
        }

        public static List<CarType> GetCarTypeBLL()       //To get the Status List
        {
            List<CarType> cartype = null;

            try
            {
                cartype = CarDAL.GetCarTypeDAL1();
            }
            catch (CarException ex)
            {
                throw ex;
            }

            return cartype;
        }

        public static List<CarTransmissionType> GetTransmissionTypeBLL()       //To get the Status List
        {
            List<CarTransmissionType> transmission = null;

            try
            {
                transmission = CarDAL.GetCarTransmissionTypeDAL1();
            }
            catch (CarException ex)
            {
                throw ex;
            }

            return transmission;
        }
    }
}
