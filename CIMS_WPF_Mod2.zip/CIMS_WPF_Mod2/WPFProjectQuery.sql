use Abhijeet_Practice
go

create table Manufacturer_4315
(
Id int primary key Identity,
ManufacturerName  varchar(30) Unique,
ContactPerson varchar(30) Unique,
RegisteredOffice varchar(50) Not Null
)
go
create table CarType_4315
(
Id int primary key Identity,
CarType varchar(30) CHECK (CarType = 'Hatchback' or CarType= 'Sedan' or CarType = 'SUV')
);

create table CarTransmissionType_4315
(
Id int primary key Identity,
TransmissionName varchar(30) Check (TransmissionName = 'Automatic' or TransmissionName='Manual')
)

create table Car
(
Id int primary key identity(1,1),
Model varchar(30) unique,
ManufacturerId int Foreign Key References Manufacturer_4315(Id),
TypeId int Foreign Key References CarType_4315(Id),
Engine varchar(6),
BHP int,
TransmissionId int Foreign Key References CarTransmissionType_4315(Id),
Mileage int not null,
Seat int not null,
AirBagDetails varchar(3) check(AirBagDetails='Yes' or AirBagDetails='No'),
BootSpace int,
Price Decimal
);
go

CREATE PROCEDURE InsertCar_4315
@Model VARCHAR(30),
@ManufacturerId INT,
@TypeId INT,
@Engine Varchar(5),
@BHP int,
@TransmissionId int,
@Mileage int,
@Seat int,
@AirBagDetails varchar(30),
@BootSpace int,
@Price Decimal
AS
BEGIN
	INSERT INTO Car VALUES (@Model,@ManufacturerId,@TypeId,@Engine,@BHP,@TransmissionId,@Mileage,@Seat,@AirBagDetails,@BootSpace,@Price)
END
go

CREATE PROCEDURE UpdateCar_4315
@Model VARCHAR(30),
@ManufacturerId INT,
@TypeId INT,
@Engine Varchar(5),
@BHP int,
@TransmissionId int,
@Mileage int,
@Seat int,
@AirBagDetails varchar(30),
@BootSpace int,
@Price Decimal
AS
BEGIN
	Update Car Set Model=@Model,ManufacturerId=@ManufacturerId,TypeId=@TypeId,Engine=@Engine,BHP=@BHP,TransmissionId=@TransmissionId,Mileage=@Mileage,Seat=@Seat,AirBagDetails=@AirBagDetails,BootSpace=@BootSpace,Price=@Price
END
go

CREATE PROCEDURE DeleteCar_4315
@Model varchar(30)
AS
BEGIN
	DELETE FROM Car WHERE Model=@Model
END
go

CREATE PROCEDURE SelectCarByManufacturer_4315
@ManufacturerId int
AS
BEGIN
	SELECT * FROM Car WHERE ManufacturerId=@ManufacturerId
END
go

CREATE PROCEDURE SelectCarByModel_4315
@Model VARCHAR(50)
AS
BEGIN
	SELECT * FROM Car WHERE Model Like ('%'+@Model+'%') AND @Model <> ''
END
go

CREATE PROCEDURE SelectManufacturer_4315
AS
BEGIN
	SELECT * FROM Manufacturer_4315
END
go

CREATE PROCEDURE SelectCarType_4315
AS
BEGIN
	SELECT * FROM CarType
END
go

CREATE PROCEDURE SelectTransmissionType_4315
AS
BEGIN
	SELECT * FROM CarTransmissionType
END
go

CREATE  PROCEDURE ReturnCarID_4315
AS
BEGIN
	SELECT IDENT_CURRENT('Car')+1
END